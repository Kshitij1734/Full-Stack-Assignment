
// function checklogin() 
// {
// let username=document.getElementById('username').value;
// let password=document.getElementById('password').value;

// if (username==" ")
// {
//     alert("Please enter a username")
// }
// if(password==" ")
// {
//     alert("Please enter a password")
// }
// }
<script>
        function checkLogin(){
            var u=document.getElementById('username');
            var p=document.getElementById('password')
           if(u.value==''){
           
                alert('Username Required')
            }
                else if  (p.value == ''){

                    alert('Password Required')
                }
                else{
                    alert('Login Successfully')
                }
        //     if(u.value ==''){
        //         alert('UserName And Password Required')
        //     }
        //    else{
        //     alert('Login Successfully')

        //        }
                    }

        
    </script>