package kshitij;
import java.util.Scanner;
public class Powerofn {
public static void main(String []args)
{
	int a,b,product=1;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter base");
	a=sc.nextInt();
	System.out.println("Enter power");
	b=sc.nextInt();
	while(b>0)
	{
		product=product*a;
		b--; 
	}
	System.out.println("Value="+product);
}
}
