package kshitij;

import java.util.Scanner;

public class Searchinarray {
    public static void main(String[] args) {
        int a[] = new int[5]; 
        int n, count = 0;

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter 5 elements:");

          for (int i = 0; i < a.length; i++) {
            a[i] = sc.nextInt();
        }

        System.out.println("Array Elements:");
        for (int i = 0; i < a.length; i++) {            
        	System.out.print(a[i] + " "); 
        }
        System.out.println(); 

        System.out.println("Enter element to search:");
        n = sc.nextInt(); 
        for (int i = 0; i < a.length; i++) {
            if (a[i] == n) {
                count++;
            }
        }

        if (count > 0)
            System.out.println("Element is in the array");
        else
            System.out.println("Element is not in the array");
        
    }   
}
