package kshitij;
import java.util.Scanner;
public class Swap {
public static void main(String []args)
{
	int a,b,temp;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter value of a=");
	a=sc.nextInt();
	System.out.println("Enter value of b=");
	b=sc.nextInt();
	System.out.println("Value of a before swapping="+a);
	System.out.println("Value of b after swapping="+b);
	temp=a;
	a=b;
	b=temp;
	System.out.println("Value of a before swapping="+a);
	System.out.println("Value of b after swapping="+b);
}
}
