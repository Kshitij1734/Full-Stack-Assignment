
//Write a program to calculate sum,sub,div of two matrices.
	package kshitij;
	import java.util.Scanner;
	public class Matrixoperation1 {

		public static void main(String[] args) {
			int r, c = 0;
			
			int arr[][]= new int[3][3];
			int arr1[][]= new int[3][3];
			int calc[][]=new int[3][3];
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter 9 elements of first matrix :");
		
			for(r=0;r<3;r++)
			{
				for(c=0;c<3;c++)
				{
					arr[r][c]=sc.nextInt();	
				}
			}
							
			System.out.println("Enter 9 elements second matrix :");
			for(r=0;r<3;r++)
			{
				for(c=0;c<3;c++)
				{
					arr1[r][c]=sc.nextInt();	
				}
			}
			
			System.out.println("First Matrix :");
			for(r=0;r<3;r++)
			{
				for(c=0;c<3;c++)
				{
					System.out.print(" "+arr[r][c]);
				}
				System.out.println();
			}
			
			System.out.println("Second Matrix :");
			
			for(r=0;r<3;r++)
			{
				for(c=0;c<3;c++)
				{
					System.out.print(" "+arr1[r][c]);
				}
				System.out.println();
			}
			
			System.out.println("Addition of matrices:");   
			for(r=0;r<3;r++)
			{    
				for(c=0;c<3;c++)
					{    
					calc[r][c]=arr[r][c]+arr1[r][c];    //use - for subtraction  
					System.out.print(calc[r][c]+" ");    
					}    
				System.out.println();//new line    
			}    
			
			System.out.println("Subtraction of matrices:");
			for(r=0;r<3;r++)
			{    
				for(c=0;c<3;c++)
					{    
					calc[r][c]=arr[r][c]-arr1[r][c];    
					System.out.print(calc[r][c]+" ");    
					}    
				System.out.println();//new line    
			}   
			System.out.println("Division of matrices:");
			for(r=0;r<3;r++)
			{    
				for(c=0;c<3;c++)
					{    
					calc[r][c]=arr[r][c]/arr1[r][c];      
					System.out.print(calc[r][c]+" ");    
					}    
				System.out.println();    
			}
	}	
}
	

