//Check the given number is palindrome or not//


package kshitij;

import java.util.Scanner;

public class Pali {
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n,rev=0,z;
		System.out.println("Enter number");
		n=sc.nextInt();
		z=n;
		while(n>0)
		{
			rev=(rev * 10) + n % 10;
			n=n/10;
		}
	
	if (rev==z)
		System.out.println("Number is Palindrome");
	else
		System.out.println("Number is Not Palindrome");
	
}
}
