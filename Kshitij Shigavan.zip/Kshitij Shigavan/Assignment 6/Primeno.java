// Write a program to find prime no from 1 to 100 // 


package kshitij;

public class Primeno {
public static void main(String []args)
{
	int i,Count,j;
	for (i=1; i<=100; i++)
	{
		Count=0;
		  for(j=1; j<=i; j++)
		  {
			  if(i%j==0) Count++;
		  }
		  if (Count==2)System.out.println(i);
	}
}
}
