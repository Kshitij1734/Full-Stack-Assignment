// Write a program to find prime no from 1 to nth number // 


package kshitij;
import java.util.Scanner;
public class Primeno1 {
public static void main(String []args)
{
	int i,Count,j,n;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter max number:");
	n=sc.nextInt();
	for (i=1; i<=n; i++)
	{
		Count=0;
		  for(j=1; j<=i; j++)
		  {
			  if(i%j==0) Count++;
		  }
		  if (Count==2)System.out.println(i);
	}
}
}