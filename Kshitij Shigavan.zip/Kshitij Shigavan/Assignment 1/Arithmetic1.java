package kshitij;

public class Arithmetic1 {
void sum(int a, int b)
{
	int s=a+b;
	System.out.println("Addition ="+s);
}
void sub(int m, int n)
{
	sum(10,5);
	int t=m-n;
	System.out.println("Subtraction ="+t);
}
void mul(int o, int p)
{
	sub(10,5);
	int u=o*p;
	System.out.println("Multipliction ="+u);
}
void div(int q, int r)
{
	mul(10,5);
	int v=q/r;
	System.out.println("Division ="+v);
}
void modulo(int c, int d)
{
	div(10,5);
	int w=c%d;
	System.out.println("Modulo ="+w);
}
public static void main(String[]args)
{
	Arithmetic1 obj=new Arithmetic1();
	obj.modulo(10,3);
}
}
