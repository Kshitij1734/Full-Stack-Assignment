package kshitij;

public class Arithmetic2 {
void sum(int a, int b)
{
	int s=a+b;
	System.out.println("Addition ="+s);
}
void sub(int m, int n)
{

	int t=m-n;
	System.out.println("Subtraction ="+t);
}
void mul(int o, int p)
{

	int u=o*p;
	System.out.println("Multipliction ="+u);
}
void div(int q, int r)
{

	int v=q/r;
	System.out.println("Division ="+v);
}
void modulo(int c, int d)
{
	
	int w=c%d;
	System.out.println("Modulo ="+w);
}
public static void main(String[] args)
{
	Arithmetic2 obj=new Arithmetic2();
	obj.sum(10, 5);
	obj.sub(10, 5);
	obj.mul(10, 2);
	obj.div(20, 5);
	obj.modulo(10, 3);
}
}
