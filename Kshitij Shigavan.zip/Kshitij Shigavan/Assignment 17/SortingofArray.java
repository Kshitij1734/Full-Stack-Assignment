//Sorting Of Array

package kshitij;
import java.util.Arrays;
public class SortingofArray {
	public static void main(String []args)
	{
		int array[]= {5,3,8,6,1,9,2};
		System.out.println("Original Array: "+ Arrays.toString(array));
		
		Arrays.sort(array);
		
		System.out.println("Sorted Array: " + Arrays.toString(array));
	}

}
