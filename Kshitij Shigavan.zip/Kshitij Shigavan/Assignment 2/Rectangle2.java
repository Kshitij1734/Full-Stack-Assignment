package kshitij;

public class Rectangle2 {
float area,perimeter;
void area(float l,float b)
{
	area=l*b;
	System.out.println("Area="+area);
}
void perimeter(float l,float b)
{
	perimeter=2*(l+b);
	System.out.println("Perimeter="+perimeter);
}
public static void main(String []args)
{
	Rectangle2 obj=new Rectangle2();
	obj.area(10,20);
	obj.perimeter(10,8);
	
}
}

